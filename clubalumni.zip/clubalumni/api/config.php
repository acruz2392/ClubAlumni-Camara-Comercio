<?php
/**
 * Configuración real del backend — NO se sube al repo (gitignored).
 * Si tu compañero también necesita una copia, pásasela por canal seguro.
 */

return [
    /* === Base de datos IONOS === */
    'db' => [
        'host' => 'db5020003363.hosting-data.io',
        'name' => 'dbs15431241',
        'user' => 'dbu5029324',
        'pass' => 'alumni2526.',
    ],

    /* === CORS ===
     * Lista de orígenes permitidos. En producción IONOS la web y la API
     * van en el mismo dominio, así que CORS apenas importa (same-origin).
     * Aún así, añade aquí tu dominio definitivo cuando lo tengas.
     */
    'allowed_origins' => [
        'http://localhost',
        'http://localhost:8080',
        // Añade aquí el dominio real cuando IONOS te lo asigne, por ejemplo:
        // 'https://alumni.camarafp.es',
        // 'https://home310917642-xxxx.ionos.space',
    ],

    /* === HTTPS ===
     * true en producción (con SSL activado en IONOS).
     * Si todavía no has activado SSL en el panel, pon false temporalmente.
     */
    'force_https' => true,

    /* === Sesiones === */
    'session_name'     => 'ALUMNISESS',
    'session_lifetime' => 7 * 24 * 3600,  // 7 días

    /* === Rate limit del login === */
    'login_max_attempts' => 5,
    'login_window'       => 300,

    /* === Subscripciones push máximas por usuario === */
    'push_subs_max_per_user' => 5,
];
