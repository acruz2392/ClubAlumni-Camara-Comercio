<?php
return [
    'publicKey'  => 'BPeuQLdHgXWLLJKfaNK7ebXZXV8xNzYs2Z8xJsyCVYeyE1NRbiey4yhu8b5ypozUw4aJ8YOwkYOWp5EKJVGwBho',
    'privateKey' => 'NsWJ8TQeGs6D6izC8bNQWW4sPT79nDOcVAMkc6YKNRI',
    'subject'    => 'mailto:alumni@camarafp.es',
];
